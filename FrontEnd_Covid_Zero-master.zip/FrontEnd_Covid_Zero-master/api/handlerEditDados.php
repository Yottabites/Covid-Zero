<?php

header('Content-Type:application/json');

require_once 'autoload.php';

#Only Put and Delete Methods
