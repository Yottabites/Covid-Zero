<?php


	require_once 'Modelo/conexao.php';
	require_once 'Modelo/modelo.php';
	require_once 'Modelo/actionUserModelo.php';
	require_once 'Controlador/usuarios.php';
	require_once 'Controlador/dados.php';
	require_once 'Controlador/acaoUsuario.php';
	require_once 'Controlador/profissionaisSaude.php';